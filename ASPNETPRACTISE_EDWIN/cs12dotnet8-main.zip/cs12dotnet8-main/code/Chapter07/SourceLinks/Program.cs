﻿string name = "Timothée Chalamet";
int length = name.Count();
Console.WriteLine("{name} has {length} characters.");
