﻿ConfigureConsole(); // Sets US English by default.
FilterAndSort();
//JoinCategoriesAndProducts();
//GroupJoinCategoriesAndProducts();
//ProductsLookup();
//AggregateProducts();
//PagingProducts();
//OutputProductsAsXml();
//ProcessSettings();
//CustomExtensionMethods();
